﻿Project 1 - Samurai Shodown

Samurai Shodown (known as Samurai Spirits in Japan), 
is the first entry of a series of competitive fighting 
games of the same name, it was created for the NEO GEO 
arcade and home platform, the game was developed and 
published by the studio SNK and its release took place 
in July 7 of 1993.

The history of the game is set in the feudal-era Japan, 
it drives us into a battle between good and evil, with 
some fictional and some real characters from the old Japan.

Group Github: https://github.com/albertec1/Samurai-Shodown-Project
Web: https://gromeu2000.github.io/Samurai-Shodown-Project/
Gameplay: https://www.youtube.com/watch?v=wFXMrBeGuZ8&feature=youtu.be

Team members:
- Management: Marc Gallardo Quesada https://github.com/Marchusky

- Art/Design: Gerard Romeu Vidal https://github.com/Gromeu2000

- Programmer: Albert Espinosa Castillo https://github.com/albertec1

- QA: Marc San José Martínez https://github.com/marcsjm19

Instructions:
Download the game file in which you will find the executable. 
Initializate it to play the game, further instructions inside the game.
Q key: select character(player 1)
1 key(number): select character(player 2)
SPACE key: next scene
ESC key: Exit game

Playing with controllers(Xbox controllers)
Out of fight:
- A: select character/next scene
- game pad: movement
In Fight:
- A: light attack
- X: medium attack
- A + X: strong attack
- Y: light kick
- B: medium kick
- Y + X: strong kick
- A + A + A: Splash Fount
- left + down + right + A: power gradiation
- left + right + X: Lance de Lion


Playing with keyboard:
-Player 1 instructions:
	Arrows: player movement (left to right, jump, crouch)(character selection)
	A key: sword, punch light attack
	D key: kick light attack

-Player 2 instructions: 
	U, H, J, K: up, left, right, crouch, left respectively (character selection)
	2 key(number): sword, punch light attack
	3 key(number):kick light attack

List of Versions:
0.1: Scroll an empty background with limits.
0.2: Scene switching + Added Audio
0.3: Player movement and animations + Particles 
0.4: Player movement limits + Colliders + God Mode
0.45: Added Fonts + Win/Lose condition
0.5: two players gameplay
0.6: Charlotte character implemented
0.7: Controllers and combos implemented
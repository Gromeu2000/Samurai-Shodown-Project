Project 1 - Samurai Shodown

Samurai Shodown (known as Samurai Spirits in Japan), 
is the first entry of a series of competitive fighting 
games of the same name, it was created for the NEO GEO 
arcade and home platform, the game was developed and 
published by the studio SNK and its release took place 
in July 7 of 1993.

The history of the game is set in the feudal-era Japan, 
it drives us into a battle between good and evil, with 
some fictional and some real characters from the old Japan.

Team members:
- Management: Marc Gallardo Quesada https://github.com/Marchusky

- Art/Design: Gerard Romeu Vidal https://github.com/Gromeu2000

- Programmer: Albert Espinosa Castillo https://github.com/albertec1

- QA: Marc San Jos� Mart�nez https://github.com/marcsjm19

Instructions:
Download the game file in which you will find the executable. 
Initializate it to play the game, further instructions inside the game.

List of Versions:
0.1: Scroll an empty background with limits.
0.2: Screen + music switching
 